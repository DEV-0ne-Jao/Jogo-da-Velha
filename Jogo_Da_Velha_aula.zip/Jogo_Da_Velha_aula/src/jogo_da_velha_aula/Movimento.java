/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogo_da_velha_aula;

/**
 *
 * @author 04423582023
 */
public class Movimento {
    
}
