//Soli Deo Gloria

package jogo_da_velha_aula;
public class Movimento {
    public int x;
    public int y;
    public Movimento(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public Movimento(String ms){
        this.x = Integer.parseInt( ms.trim().split(",")[0] );
        this.y = Integer.parseInt( ms.trim().split(",")[1] );
    }
}
