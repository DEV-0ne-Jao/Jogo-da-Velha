//Soli Deo Gloria

package jogo_da_velha_aula;
public class Movimento {
    public int x;
    public int y;
    public Movimento(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public Movimento(String ms) throws ExecaoMovimentoInvalido{
        
        try{
        String[] pedacos = ms.split(",");
        this.x = Integer.parseInt( pedacos[0] );
        this.y = Integer.parseInt( pedacos[1] );
        } catch( Exception e) {
            throw new ExecaoMovimentoInvalido("A jogada é invalida!!");
        }
    }
}
