//Soli Deo Gloria
package jogo_da_velha_aula;
public class Constantes {
    public static final char[] SIMBOLOS_JOGADORES = {'x', 'o'};
    public static final int TAMANHO_TABULEIRO = 3;
}