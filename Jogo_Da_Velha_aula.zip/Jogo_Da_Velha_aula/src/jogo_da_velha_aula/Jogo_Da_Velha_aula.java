//Soli Deo Gloria
package jogo_da_velha_aula;
public class Jogo_Da_Velha_aula {
    public static void main(String[] args) {
        Jogo j = new Jogo();
        j.jogar();
    }
}