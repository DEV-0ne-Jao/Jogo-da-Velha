//Soli Deo Gloria
package jogo_da_velha_aula;

public class Jogo {

    Tabuleiro tabuleiro = new Tabuleiro();
    Jogador[] jogadores = new Jogador[Constantes.SIMBOLOS_JOGADORES.length];
    InterfaceGrafica ig = new InterfaceGrafica();
    private int indiceJogadorAtual = -1;

    public void jogar() {
        ig.imprimirTituloDoJogo();
        //tabuleiro.limpar();
        //tabuleiro.escrever(0, 0);

        for (int i = 0; i < jogadores.length; i++) {
            Jogador jogador = criarJogador(i);
            jogadores[i] = jogador;
        }

        Jogador jogadorAtual = proximoJogador();
        Jogador vencedor = null;
        boolean jogoTerminado = false;

        //game loop
        while (!jogoTerminado) {
            tabuleiro.escrever();
            boolean sequenciaEncontrada = jogadorAtual.jogar();
            //Se ele encontrou a sequencia, o jogo acaba, se não, continua o loop
            if (sequenciaEncontrada) {
                jogoTerminado = true;
                vencedor = jogadorAtual;
            } else {
                if (tabuleiro.estaCheio()) {
                    jogoTerminado = true;
                }
            }
            jogadorAtual = proximoJogador();
        }
        if (vencedor == null) {
            ig.imprimirTexto("O jogo terminou empatado");
        } else {
            ig.imprimirTexto("O jogador " + vencedor.getNome() + " venceu o jogo!");
            
        }
        tabuleiro.escrever();
        ig.imprimirTexto("Fim do jogo");

        /*
        if(tabuleiro.estaCheio()){
            ig.imprimirTexto("Empate!");
        }
         */
    }

    public Jogador criarJogador(int indice) {
        String nome = ig.lerEntrada("Jogador " + (indice + 1) + " digite seu nome");
        char simbolo = Constantes.SIMBOLOS_JOGADORES[indice];
        Jogador jogador = new Jogador(nome, simbolo, tabuleiro);
        return jogador;
    }

    private Jogador proximoJogador() {
        indiceJogadorAtual++;
        if (indiceJogadorAtual >= jogadores.length) {
            indiceJogadorAtual = 0;
        }
        return jogadores[indiceJogadorAtual];
    }

}
