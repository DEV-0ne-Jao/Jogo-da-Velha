//Soli Deo Gloria
package jogo_da_velha_aula;

public class Jogo {
    Tabuleiro tabuleiro = new Tabuleiro();
    Jogador[] jogadores = new Jogador[Constantes.SIMBOLOS_JOGADORES.length];
    InterfaceGrafica ig = new InterfaceGrafica();
    
    public void jogar(){
        ig.imprimirTituloDoJogo();
        tabuleiro.limpar();
        tabuleiro.escrever(0, 0);
        
        if(tabuleiro.estaCheio()){
            ig.imprimirTexto("Empate!");
        }
    }
    
}
