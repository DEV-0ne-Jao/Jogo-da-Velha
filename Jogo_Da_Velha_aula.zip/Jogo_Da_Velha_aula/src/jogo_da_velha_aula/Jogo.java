//Soli Deo Gloria
package jogo_da_velha_aula;

public class Jogo {
    Tabuleiro tabuleiro = new Tabuleiro();
    Jogador[] jogadores = new Jogador[Constantes.SIMBOLOS_JOGADORES.length];
    InterfaceGrafica ig = new InterfaceGrafica();
    private int indiceJogadorAtual = 0;
    
    public void jogar(){
        ig.imprimirTituloDoJogo();
        tabuleiro.limpar();
        tabuleiro.escrever(0, 0);
        
        if(tabuleiro.estaCheio()){
            ig.imprimirTexto("Empate!");
        }
    }
    
    public Jogador criarJogador(int indice) {
        String nome = ig.lerEntrada("Jogador " + (indice + 1) + " digite seu nome");
        char simbolo = Constantes.SIMBOLOS_JOGADORES[indice];
        Jogador jogador = new Jogador(nome, simbolo, tabuleiro);
    }
    
    private Jogador proximoJogador() {
        indiceJogadorAtual++;
        if(indiceJogadorAtual >= jogadores.length) {
            indiceJogadorAtual = 0;
        }
        return jogadores[indiceJogadorAtual];
    }
    
}
