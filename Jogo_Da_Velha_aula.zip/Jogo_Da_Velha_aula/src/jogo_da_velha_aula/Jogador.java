//Soli Deo Gloria

package jogo_da_velha_aula;
public class Jogador {
    public char simbolo;
    public String nome;
    public Tabuleiro tabuleiro;

    public Jogador(char simbolo, String nome, Tabuleiro tabuleiro) {
        this.simbolo = simbolo;
        this.nome = nome;
        this.tabuleiro = tabuleiro;
    }
    
    public Movimento realizarJogada(){
        InterfaceGrafica ig = new InterfaceGrafica();
        String posicao = ig.lerEntrada("Jogador " + this.nome + "=>");
        Movimento m = new Movimento(posicao);
        return m;
    }
    
    public void jogar() {
        Movimento m = realizarJogada();
        tabuleiro.realizarJogada(this, m);
    }
}