//Soli Deo Gloria

package jogo_da_velha_aula;
public class Jogador {
    public char simbolo;
    public String nome;
    public Tabuleiro tabuleiro;

    public Jogador (String nome, char simbolo, Tabuleiro tabuleiro) {
        this.simbolo = simbolo;
        this.nome = nome;
        this.tabuleiro = tabuleiro;
    }
    
    public Movimento realizarJogada() throws ExecaoMovimentoInvalido {
        InterfaceGrafica ig = new InterfaceGrafica();
        String posicao = ig.lerEntrada("Jogador " + this.nome + "=>");
        Movimento m = new Movimento(posicao);
        return m;
    }
    
    public boolean jogar() {
        Movimento m = realizarJogada();
        return tabuleiro.realizarJogada(this, m);
    }

    public char getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(char simbolo) {
        this.simbolo = simbolo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }

    public void setTabuleiro(Tabuleiro tabuleiro) {
        this.tabuleiro = tabuleiro;
    }
}