// Soli Deo Gloria

package jogo_da_velha_aula;
public class ExecaoMovimentoInvalido extends Exception{

    public ExecaoMovimentoInvalido() {
    }

    public ExecaoMovimentoInvalido(String message) {
        super(message);
    }

    public ExecaoMovimentoInvalido(String message, Throwable cause) {
        super(message, cause);
    }

    public ExecaoMovimentoInvalido(Throwable cause) {
        super(cause);
    }

    public ExecaoMovimentoInvalido(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
}
