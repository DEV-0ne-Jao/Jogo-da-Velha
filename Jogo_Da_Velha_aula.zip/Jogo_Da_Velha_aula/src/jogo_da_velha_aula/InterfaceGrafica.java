//Soli Deo Gloria
package jogo_da_velha_aula;
import java.util.Scanner;
public class InterfaceGrafica {
    Scanner sc = new Scanner(System.in);
    
    public void imprimirTexto(String texto) {
        System.out.println(texto);
    }
    
    public void imprimirTextoSemQuebra(String texto) {
        System.out.print(texto);
    }
    public void pularLinha() {
        System.out.println();
    }
    public void imprimirTituloDoJogo() {
        imprimirTexto("===============");
        imprimirTexto("|Jogo da Velha|");
        imprimirTexto("===============");
        pularLinha();
    }
    
    public String lerEntrada(String texto) {
        imprimirTexto(texto);
        String text = sc.nextLine();
        return text.trim();
    }
}
