//Soli Deo Gloria
package jogo_da_velha_aula;
public class Tabuleiro {
    char [][] matriz = new char[Constantes.TAMANHO_TABULEIRO][Constantes.TAMANHO_TABULEIRO];
    InterfaceGrafica ig = new InterfaceGrafica();
    
    public void limpar() {
        for (int i = 0; i<matriz.length; i++) {
            for (int j = 0; j<matriz[i].length; j++) {
                matriz[i][j] = ' ';
            }
        }
    }
    public void escrever(int x, int y) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                ig.imprimirTextoSemQuebra( String.valueOf(matriz[i][j]) );
                ig.imprimirTextoSemQuebra("|");
            }
            ig.pularLinha();
            ig.imprimirTextoSemQuebra("--------");
        }
    }
}
