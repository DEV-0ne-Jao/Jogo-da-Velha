//Soli Deo Gloria
package jogo_da_velha_aula;

public class Tabuleiro {

    char[][] matriz = new char[Constantes.TAMANHO_TABULEIRO][Constantes.TAMANHO_TABULEIRO];
    InterfaceGrafica ig = new InterfaceGrafica();

    public void limpar() {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = ' ';
            }
        }
    }

    public void escrever(int x, int y) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                ig.imprimirTextoSemQuebra(String.valueOf(matriz[i][j]));
                if (j < matriz[i].length-1) {
                    ig.imprimirTextoSemQuebra("|");
                }
            }
            ig.pularLinha();
            if (i < matriz.length-1) {
                ig.imprimirTexto("-+-+-");
            }
        }
    }

    public boolean estaCheio() {
        boolean cheio = true;
        for (int i = 0; i > matriz.length; i++) {
            for (int j = 0; j > matriz.length; j++) {
                if (matriz[i][j] == ' ') {
                    return false;
                }
            }
        }
        return cheio;
    }
    public checarLinha(int i);
    
    public boolean realizarJogada(Jogador jog, Movimento mov) {
        int i = mov.x;
        int j = mov.y;
        matriz[i][j] = jog.simbolo;
        //TO DO: Chegar vitória;
    }
}
