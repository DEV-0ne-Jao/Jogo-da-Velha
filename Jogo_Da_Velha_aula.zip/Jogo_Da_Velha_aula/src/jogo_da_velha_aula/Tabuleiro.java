//Soli Deo Gloria
package jogo_da_velha_aula;

public class Tabuleiro {

    char[][] matriz = new char[Constantes.TAMANHO_TABULEIRO][Constantes.TAMANHO_TABULEIRO];
    InterfaceGrafica ig = new InterfaceGrafica();

    public Tabuleiro() {
    }

    public void limpar() {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = ' ';
            }
        }
    }

    public void escrever(int x, int y) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                ig.imprimirTextoSemQuebra(String.valueOf(matriz[i][j]));
                if (j < matriz[i].length-1) {
                    ig.imprimirTextoSemQuebra("|");
                }
            }
            ig.pularLinha();
            if (i < matriz.length-1) {
                ig.imprimirTexto("-+-+-");
            }
        }
    }

    public boolean estaCheio() {
        boolean cheio = true;
        for (int i = 0; i > matriz.length; i++) {
            for (int j = 0; j > matriz.length; j++) {
                if (matriz[i][j] == ' ') {
                    return false;
                }
            }
        }
        return cheio;
    }
    public boolean checarLinha(int i, Jogador jogador){
        char simbolo = jogador.getSimbolo();
        for(int j=0; j<Constantes.TAMANHO_TABULEIRO; j++){
            if(matriz[i][j] != simbolo){
                return false;
            }
        }
        return true;
    }
    public boolean checarColuna(int j, Jogador jogador){
        char simbolo = jogador.getSimbolo();
        for(int i=0; i<Constantes.TAMANHO_TABULEIRO; i++){
            if(matriz[i][j] != simbolo){
                return false;
            }
        }
        return true;
    }
    public boolean checarLinhas(Jogador jogador) {
        
        for(int i=0; i<Constantes.TAMANHO_TABULEIRO; i++){
            if(checarLinha(i, jogador) == true){
                return true;
            }
        }
        return false;
    }
    public boolean checarColunas(Jogador jogador) {
        
        for(int j=0; j<Constantes.TAMANHO_TABULEIRO; j++){
            if(checarColuna(j, jogador) == true){
                return true;
            }
        }
        return false;
    }
    public boolean checarDiagonal1(Jogador jogador){
        char simbolo = jogador.getSimbolo();
        for(int i=0; i<Constantes.TAMANHO_TABULEIRO; i++){
            if(matriz[i][i] == simbolo) {
                return true;
            }
        }
        return false;
    }
    
    public boolean checarDiagonal2(Jogador jogador){
        char simbolo = jogador.getSimbolo();
        for(int i=Constantes.TAMANHO_TABULEIRO-1, j = 0 ; i>0; i--, j++){
            if(matriz[i][j] == simbolo) {
                return true;
            }
        }
        return false;
    }
    
    public boolean realizarJogada(Jogador jog, Movimento mov) {
        int i = mov.x;
        int j = mov.y;
        matriz[i][j] = jog.simbolo;
        //TO DO: Chegar vitória;
        
        return checarLinhas(jog) ||
               checarColunas(jog) ||
               checarDiagonal1(jog) ||
               checarDiagonal2(jog);
    }
}
