//Soli Deo Gloria
public class GameManager {
    public static void main(String[] args) {
        TelaPlay play = new TelaPlay();
        play.setVisible(true);
    }
}
