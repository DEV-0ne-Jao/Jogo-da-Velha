//Soli Deo Gloria
package JogoDaVelha;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelPartida extends javax.swing.JPanel {

    private int vez = 1;
    static int[][] tabuleiroLogico = new int[3][3];

    static public boolean checarVitoria(){
        if(
            tabuleiroLogico[1][0] == 1 &&
            tabuleiroLogico[1][1] == 1 &&
            tabuleiroLogico[1][2] == 1) {
            
        }
    }
    
    public PanelPartida() {
        initComponents();
        this.setBounds(Globals.getTela().getLayer().getBounds());

        panelTabuleiro.setBounds(300, 100, 600, 600);

        int panelWidth = panelTabuleiro.getWidth() / 3;
        int panelHeight = panelTabuleiro.getHeight() / 3;

        JPanel[][] paineisTabuleiro = new JPanel[3][3];

        //Criar e inicializar o tabuleiro logico
        for (int i = 0; i < tabuleiroLogico.length; i++) {
            for (int j = 0; j < tabuleiroLogico[i].length; j++) {
                tabuleiroLogico[i][j] = 0;
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int linha = i;
                int coluna = j;

                paineisTabuleiro[i][j] = new JPanel();
                paineisTabuleiro[i][j].setLayout(null);

                JLabel imagem = new JLabel();
                paineisTabuleiro[i][j].add(imagem);

                paineisTabuleiro[i][j].addMouseListener(new MouseListener() {
                    public void mouseClicked(MouseEvent e) {
                        System.out.println("Clicou");
                        if (vez == 1 && tabuleiroLogico[linha][coluna] == 0) {
                            
                            Image img = Globals.getP1().getForma().getImage();
                            
                            img = img.getScaledInstance(
                                paineisTabuleiro[linha][coluna].getWidth(),
                                paineisTabuleiro[linha][coluna].getHeight(),
                                Image.SCALE_SMOOTH);
                            
                            imagem.setIcon( new ImageIcon(img));

                            tabuleiroLogico[linha][coluna] = vez;

                            Globals.getTela().getLayer().repaint();
                            Globals.getTela().getLayer().revalidate();

                            vez++;
                        } else if (vez == 2 && tabuleiroLogico[linha][coluna] == 0) {

                            
                            Image img = Globals.getP2().getForma().getImage();
                            
                            img = img.getScaledInstance(
                                paineisTabuleiro[linha][coluna].getWidth(),
                                paineisTabuleiro[linha][coluna].getHeight(),
                                Image.SCALE_SMOOTH);
                            
                            imagem.setIcon( new ImageIcon(img));

                            tabuleiroLogico[linha][coluna] = vez;

                            Globals.getTela().getLayer().repaint();
                            Globals.getTela().getLayer().revalidate();

                            vez--;
                        }
                    }

                    public void mousePressed(MouseEvent e) {}
                    public void mouseReleased(MouseEvent e) {}
                    public void mouseEntered(MouseEvent e) {}
                    public void mouseExited(MouseEvent e) {}
                });

                paineisTabuleiro[i][j].setBackground(new Color(255, 0, 0, 125));
                paineisTabuleiro[i][j].setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK, 3));

                panelTabuleiro.add(paineisTabuleiro[i][j]);

                paineisTabuleiro[i][j].setBounds(
                        i * panelWidth,
                        j * panelHeight,
                        panelWidth,
                        panelHeight
                );
                imagem.setBounds( 0, 0,
                        paineisTabuleiro[i][j].getWidth(),
                        paineisTabuleiro[i][j].getHeight() );

                System.out.println("Bounds do jlabel chamado 'imagem' do painel\n"
                        + "X: " + imagem.getX()
                        + "Y: " + imagem.getY()
                        + "Width: " + imagem.getWidth()
                        + "Height: " + imagem.getHeight());
                imagem.repaint();
                imagem.revalidate();
            }
        }

        panelTabuleiro.revalidate();
        panelTabuleiro.repaint();
        Globals.getTela().getLayer().repaint();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTabuleiro = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        panelTabuleiro.setBackground(new java.awt.Color(204, 204, 204));
        panelTabuleiro.setLayout(null);
        panelTabuleiro.add(jLabel1);
        jLabel1.setBounds(10, 30, 200, 200);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(300, Short.MAX_VALUE)
                .addComponent(panelTabuleiro, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(300, 300, 300))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(219, Short.MAX_VALUE)
                .addComponent(panelTabuleiro, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel panelTabuleiro;
    // End of variables declaration//GEN-END:variables
}
