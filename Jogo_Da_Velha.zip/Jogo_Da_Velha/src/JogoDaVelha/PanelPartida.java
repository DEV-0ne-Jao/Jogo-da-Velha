//Soli Deo Gloria
package JogoDaVelha;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelPartida extends javax.swing.JPanel {

    static private int vez = 1;
    static int[][] tabuleiroLogico = new int[3][3];
    boolean temVencedor = false;

    static public boolean checarVitoria(int player) {

        for (int linha = 0; linha < tabuleiroLogico.length; linha++) {

            //Checagem de linha
            boolean linhaAtual = true;
            for (int coluna = 0; coluna < tabuleiroLogico[linha].length; coluna++) {

                if (tabuleiroLogico[linha][coluna] != player) {
                    linhaAtual = false;
                }

                System.out.println("Checagem de linha:" + linha + coluna + "\n"
                        + "valor atual da linha: " + tabuleiroLogico[linha][coluna]
                        + "   Estado da linha atual: " + linhaAtual
                        + "\n"
                );
            }
            if (linhaAtual) {
                return true;
            }

            //Checagem de coluna
            boolean colunaAtual = true;
            for (int coluna = 0; coluna < tabuleiroLogico[linha].length; coluna++) {
                if (tabuleiroLogico[coluna][linha] != player) {
                    colunaAtual = false;
                }
                System.out.println("Checagem de coluna:" + coluna + linha + "\n"
                        + "valor atual da coluna: " + tabuleiroLogico[linha][coluna]
                        + "   Estado da coluna atual: " + linhaAtual
                        + "\n"
                );
            }
            if (colunaAtual) {
                return true;
            }

            //Checagem de diagonal 1
            if (tabuleiroLogico[0][0] == player
                    && tabuleiroLogico[1][1] == player
                    && tabuleiroLogico[2][2] == player) {
                return true;
            }

            //Checagem de diagonal 2
            if (tabuleiroLogico[0][2] == player
                    && tabuleiroLogico[1][1] == player
                    && tabuleiroLogico[2][0] == player) {
                return true;
            }
        }
        return false;
    }
     
    public void update_lbl_JogadorAtual(){
        if(vez ==1){
            lblVezJogador.setText("A vez é do jogador: " + Globals.getP1().getNome());
        } else {
            lblVezJogador.setText("A vez é do jogador: " + Globals.getP2().getNome());
        }
    }
    
    public PanelPartida() {
        initComponents();
        this.setBounds(Globals.getTela().getLayer().getBounds());
        lblVencedor.setBounds(300, 60, 5000, 50);
        lblVencedor.setMinimumSize(new Dimension(100, 50));
        lblVencedor.setMaximumSize(new Dimension(5000, 50));
        panelTabuleiro.setBounds(300, 150, 600, 600);
        update_lbl_JogadorAtual();

        int panelWidth = panelTabuleiro.getWidth() / 3;
        int panelHeight = panelTabuleiro.getHeight() / 3;

        JPanel[][] paineisTabuleiro = new JPanel[tabuleiroLogico.length][tabuleiroLogico[0].length];

        //Criar e inicializar o tabuleiro logico
        for (int i = 0; i < tabuleiroLogico.length; i++) {
            for (int j = 0; j < tabuleiroLogico[i].length; j++) {
                tabuleiroLogico[i][j] = 0;
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int linha = i;
                int coluna = j;

                paineisTabuleiro[i][j] = new JPanel();
                paineisTabuleiro[i][j].setLayout(null);

                JLabel imagem = new JLabel();
                paineisTabuleiro[i][j].add(imagem);

                paineisTabuleiro[i][j].addMouseListener(new MouseListener() {
                    public void mouseClicked(MouseEvent e) {
                        if (!temVencedor) {
                            if (vez == 1 && tabuleiroLogico[linha][coluna] == 0) {

                                Image img = Globals.getP1().getForma().getImage();

                                img = img.getScaledInstance(
                                        paineisTabuleiro[linha][coluna].getWidth(),
                                        paineisTabuleiro[linha][coluna].getHeight(),
                                        Image.SCALE_SMOOTH);

                                imagem.setIcon(new ImageIcon(img));

                                tabuleiroLogico[linha][coluna] = vez;

                                if (checarVitoria(vez)) {
                                    lblVencedor.setText("O Vencedor é o player: " + Globals.getP1().getNome());
                                    temVencedor = true;
                                }

                                Globals.getTela().getLayer().repaint();
                                Globals.getTela().getLayer().revalidate();

                                vez++;
                                update_lbl_JogadorAtual();
                                
                            } else if (vez == 2 && tabuleiroLogico[linha][coluna] == 0) {

                                Image img = Globals.getP2().getForma().getImage();

                                img = img.getScaledInstance(
                                        paineisTabuleiro[linha][coluna].getWidth(),
                                        paineisTabuleiro[linha][coluna].getHeight(),
                                        Image.SCALE_SMOOTH);

                                imagem.setIcon(new ImageIcon(img));

                                tabuleiroLogico[linha][coluna] = vez;

                                if (checarVitoria(vez)) {
                                    lblVencedor.setText("O Vencedor é o player " + Globals.getP2().getNome());
                                    temVencedor = true;
                                }

                                Globals.getTela().getLayer().repaint();
                                Globals.getTela().getLayer().revalidate();

                                vez--;
                                update_lbl_JogadorAtual();
                            }
                        }
                    }

                    public void mousePressed(MouseEvent e) {
                    }

                    public void mouseReleased(MouseEvent e) {
                    }

                    public void mouseEntered(MouseEvent e) {
                    }

                    public void mouseExited(MouseEvent e) {
                    }
                });

                paineisTabuleiro[i][j].setBackground(new Color(255, 0, 0, 125));
                paineisTabuleiro[i][j].setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK, 3));

                panelTabuleiro.add(paineisTabuleiro[i][j]);

                paineisTabuleiro[i][j].setBounds(
                        i * panelWidth,
                        j * panelHeight,
                        panelWidth,
                        panelHeight
                );
                imagem.setBounds(0, 0,
                        paineisTabuleiro[i][j].getWidth(),
                        paineisTabuleiro[i][j].getHeight());

                System.out.println("Bounds do jlabel chamado 'imagem' do painel\n"
                        + "X: " + imagem.getX()
                        + "Y: " + imagem.getY()
                        + "Width: " + imagem.getWidth()
                        + "Height: " + imagem.getHeight());
                imagem.repaint();
                imagem.revalidate();
            }
        }

        panelTabuleiro.revalidate();
        panelTabuleiro.repaint();
        Globals.getTela().getLayer().repaint();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTabuleiro = new javax.swing.JPanel();
        lblVencedor = new javax.swing.JLabel();
        btnReset = new javax.swing.JButton();
        btnNovaPartida = new javax.swing.JButton();
        btnTrocar = new javax.swing.JButton();
        lblVezJogador = new javax.swing.JLabel();

        setLayout(null);

        panelTabuleiro.setBackground(new java.awt.Color(204, 204, 204));
        panelTabuleiro.setLayout(null);
        add(panelTabuleiro);
        panelTabuleiro.setBounds(300, 200, 600, 600);

        lblVencedor.setFont(new java.awt.Font("Vineta BT", 2, 32)); // NOI18N
        lblVencedor.setMaximumSize(new java.awt.Dimension(500, 44));
        lblVencedor.setOpaque(true);
        add(lblVencedor);
        lblVencedor.setBounds(300, 40, 600, 156);

        btnReset.setFont(new java.awt.Font("Leelawadee UI", 1, 18)); // NOI18N
        btnReset.setText("Resetar partida");
        btnReset.addActionListener(this::btnResetActionPerformed);
        add(btnReset);
        btnReset.setBounds(930, 220, 250, 120);

        btnNovaPartida.setFont(new java.awt.Font("Leelawadee UI", 1, 18)); // NOI18N
        btnNovaPartida.setText("Criar nova partida");
        btnNovaPartida.addActionListener(this::btnNovaPartidaActionPerformed);
        add(btnNovaPartida);
        btnNovaPartida.setBounds(930, 360, 250, 130);

        btnTrocar.setFont(new java.awt.Font("Leelawadee UI", 1, 18)); // NOI18N
        btnTrocar.setText("Inverter vez");
        btnTrocar.addActionListener(this::btnTrocarActionPerformed);
        add(btnTrocar);
        btnTrocar.setBounds(930, 510, 250, 130);
        add(lblVezJogador);
        lblVezJogador.setBounds(10, 190, 220, 90);
    }// </editor-fold>//GEN-END:initComponents

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed

        for (int linha = 0; linha < tabuleiroLogico.length; linha++) {
            for (int coluna = 0; coluna < tabuleiroLogico[linha].length; coluna++) {
                tabuleiroLogico[linha][coluna] = 0;
            }
        }

        for(Component painel : panelTabuleiro.getComponents()){
            JPanel panel = (JPanel) painel;
            
            JLabel label = (JLabel) panel.getComponents()[0];
            label.setIcon(null);
            
        };
        temVencedor =false;
        vez = 1;
        lblVencedor.setText("");
        update_lbl_JogadorAtual();
        Globals.getTela().getLayer().repaint();

    }//GEN-LAST:event_btnResetActionPerformed

    private void btnNovaPartidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovaPartidaActionPerformed
        Globals.getTela().getLayer().remove(this);
        Globals.getTela().getLayer().add(new PanelCadastrar());
    }//GEN-LAST:event_btnNovaPartidaActionPerformed

    private void btnTrocarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTrocarActionPerformed
        if(vez ==1) {
            vez++;
        } else {
            vez--;
        }
        update_lbl_JogadorAtual();
    }//GEN-LAST:event_btnTrocarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNovaPartida;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnTrocar;
    private javax.swing.JLabel lblVencedor;
    private javax.swing.JLabel lblVezJogador;
    private javax.swing.JPanel panelTabuleiro;
    // End of variables declaration//GEN-END:variables
}
