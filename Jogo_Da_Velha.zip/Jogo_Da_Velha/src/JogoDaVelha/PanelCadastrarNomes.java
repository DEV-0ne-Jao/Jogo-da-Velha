package JogoDaVelha;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;

//Soli Deo Gloria

public class PanelCadastrarNomes extends javax.swing.JPanel {
    public PanelCadastrarNomes pcn = this;
    public PanelCadastrarNomes() {
        initComponents();
        this.setBounds(Globals.getTela().getLayer().getBounds());
        Globals.getTela().getLayer().repaint();
        
        encherCbx(cbxFormaP1);
        encherCbx(cbxFormaP2);
        
        
        
        btnCadastrar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(txfNomeP1.getText().trim().isEmpty() && txfNomeP2.getText().trim().isEmpty()) {
                    Globals.getP1().setNome(txfNomeP1.getText());
                    Globals.getP2().setNome(txfNomeP2.getText());
                    Globals.getTela().getLayer().remove(pcn);
                } else {
                    
                }
            }
        });
    }
    public void encherCbx(JComboBox cbx) {        
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        
        String cBase = "/jogoDaVelha/Formas/";
        
        List<ImageIcon> formas = new ArrayList<>();
        
        File pasta = new File("src/JogoDaVelha/Formas");

        File[] arquivos = pasta.listFiles();

        for (File arquivo : arquivos) {
            if (arquivo.isFile()) {
                formas.add( new ImageIcon( cBase + arquivo.getName() ) );
            }
        }
        
        for (int i = 0; i < formas.size(); i++) {
            modelo.addElement(formas.get(i));
        }
        cbx.setModel(modelo);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblP1 = new javax.swing.JLabel();
        lblP2 = new javax.swing.JLabel();
        lblN1 = new javax.swing.JLabel();
        lblN2 = new javax.swing.JLabel();
        txfNomeP1 = new javax.swing.JTextField();
        txfNomeP2 = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        lblescolhaFormaP1 = new javax.swing.JLabel();
        lblescolhaFormaP2 = new javax.swing.JLabel();
        cbxFormaP1 = new javax.swing.JComboBox<>();
        cbxFormaP2 = new javax.swing.JComboBox<>();

        lblP1.setText("Player1");

        lblP2.setText("Player2");

        lblN1.setText("Digite seu nome");

        lblN2.setText("Digite seu nome:");

        btnCadastrar.setText("Cadastrar nomes e formas");

        lblescolhaFormaP1.setText("Escolha sua forma");

        lblescolhaFormaP2.setText("Escolha sua forma");

        cbxFormaP1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbxFormaP2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(248, 248, 248)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblN1)
                            .addComponent(lblP1)
                            .addComponent(txfNomeP1, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                            .addComponent(lblescolhaFormaP1)
                            .addComponent(cbxFormaP1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(293, 293, 293)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txfNomeP2, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                            .addComponent(lblP2)
                            .addComponent(lblN2)
                            .addComponent(lblescolhaFormaP2)
                            .addComponent(cbxFormaP2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(402, 402, 402)
                        .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(367, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(278, 278, 278)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblP1)
                    .addComponent(lblP2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblN1)
                    .addComponent(lblN2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txfNomeP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfNomeP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblescolhaFormaP1)
                    .addComponent(lblescolhaFormaP2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(138, 138, 138)
                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(275, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cbxFormaP1;
    private javax.swing.JComboBox<String> cbxFormaP2;
    private javax.swing.JLabel lblN1;
    private javax.swing.JLabel lblN2;
    private javax.swing.JLabel lblP1;
    private javax.swing.JLabel lblP2;
    private javax.swing.JLabel lblescolhaFormaP1;
    private javax.swing.JLabel lblescolhaFormaP2;
    private javax.swing.JTextField txfNomeP1;
    private javax.swing.JTextField txfNomeP2;
    // End of variables declaration//GEN-END:variables
}
