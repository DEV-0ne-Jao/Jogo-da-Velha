package JogoDaVelha;


import javax.swing.ImageIcon;

//Soli Deo Gloria

public class Player {
    private int pontos;
    private String nome;
    private ImageIcon forma;

    public Player() {
    }
    
    public Player(String nome) {
        this.nome = nome;
    }

    public int getPontos() {return pontos;}
    public void setPontos(int pontos) {this.pontos = pontos;}

    public String getNome() {return nome;}
    public void setNome(String nome) {this.nome = nome;}

    public ImageIcon getForma() {return forma;}
    public void setForma(ImageIcon forma) {this.forma = forma;}
    
    
}
