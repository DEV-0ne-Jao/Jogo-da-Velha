package JogoDaVelha;

//Soli Deo Gloria
public class GameManager {
    public static void main(String[] args) {
        Globals.getTela().setVisible(true);
    }
}
