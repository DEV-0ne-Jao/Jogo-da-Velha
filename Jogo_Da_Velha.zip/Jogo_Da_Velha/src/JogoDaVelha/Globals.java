package JogoDaVelha;


import javax.swing.JFrame;

//Soli Deo Gloria
public class Globals {
    private static Player P1 = new Player();
    private static Player P2 = new Player();
    private static Tela Tela = new Tela();

    public static Player getP1() {return P1;}
    public static void setP1(Player nomeP1) {Globals.P1 = nomeP1;}

    public static Player getP2() {return P2;}
    public static void setP2(Player nomeP2) {Globals.P2 = nomeP2;}
    
    public static Tela getTela() {return Tela;}
    public static void setTela(Tela Tela) {Globals.Tela = Tela;}

    
    
}
