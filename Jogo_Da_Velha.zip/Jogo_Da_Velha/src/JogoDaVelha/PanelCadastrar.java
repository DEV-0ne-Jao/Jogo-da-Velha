package JogoDaVelha;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

//Soli Deo Gloria
public class PanelCadastrar extends javax.swing.JPanel {

    public List<String> opcoes = new ArrayList<>();
    public List<String> opcoesP1 = new ArrayList<>();
    public List<String> opcoesP2 = new ArrayList<>();

    public void inicializarOpcoes() {
        opcoes.removeAll(opcoes);

        File pasta = new File("src/JogoDaVelha/Formas");
        File[] arquivos = pasta.listFiles();
        for (File arquivo : arquivos) {
            if (arquivo.isFile()) {
                opcoes.add(arquivo.getName());
            }
        }
        opcoesP1.addAll(opcoes);
        opcoesP2.addAll(opcoes);
    }

    public void encherCbx(JComboBox cbx, String p) {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        
        if (p == "1") {
            Object antigaEscolha = cbx.getSelectedItem();
            
            opcoesP1.clear();
            opcoesP1.addAll(opcoes);
            opcoesP1.remove( opcoesP2.get( cbxFormaP2.getSelectedIndex() ) );
            for (int i = 0; i < opcoesP1.size(); i++) {
                String[] nomeQuebrado = opcoesP1.get(i).split("\\.");
                String nome = nomeQuebrado[0];
                modelo.addElement(nome);
            }
            cbx.setModel(modelo);
            
            cbx.setSelectedItem(antigaEscolha);
            
        } else if (p == "2") {
            
            Object antigaEscolha = cbx.getSelectedItem();
            
            opcoesP2.clear();
            opcoesP2.addAll(opcoes);
            opcoesP2.remove( opcoesP1.get( cbxFormaP1.getSelectedIndex() ) );
            for (int i = 0; i < opcoesP2.size(); i++) {
                String[] nomeQuebrado = opcoesP2.get(i).split("\\.");
                String nome = nomeQuebrado[0];
                modelo.addElement(nome);
            }

            cbx.setModel(modelo);
            cbx.setSelectedItem(antigaEscolha);
        }
    }
    public PanelCadastrar pcn = this;

    public PanelCadastrar() {
        initComponents();
        this.setBounds(Globals.getTela().getLayer().getBounds());
        Globals.getTela().getLayer().repaint();

        inicializarOpcoes();
        
        
        cbxFormaP1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Não aceita imagens do tipo .paint

                String selecionado = opcoesP1.get(cbxFormaP1.getSelectedIndex());

                String caminho = ("/JogoDaVelha/Formas" + "/" + selecionado);

                Class classeAtual = getClass();
                URL recurso = classeAtual.getResource(caminho);

                if (recurso != null) {

                    ImageIcon icone = new ImageIcon(recurso);
                    
                    Image img = icone.getImage();
                    img = img.getScaledInstance(lblFormaP1.getBounds().width, lblFormaP1.getBounds().height, Image.SCALE_SMOOTH);
                    icone = new ImageIcon(img);
                    
                    lblFormaP1.setIcon(icone);
                }
                encherCbx(cbxFormaP2, "2");
            }
        });

        cbxFormaP2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Não aceita imagens do tipo .paint

                String selecionado = opcoesP2.get(cbxFormaP2.getSelectedIndex());

                String caminho = ("/JogoDaVelha/Formas" + "/" + selecionado);

                Class classeAtual = getClass();
                URL recurso = classeAtual.getResource(caminho);

                if (recurso != null) {

                    ImageIcon icone = new ImageIcon(recurso);
                    
                    Image img = icone.getImage();
                    img = img.getScaledInstance(lblFormaP2.getBounds().width, lblFormaP2.getBounds().height, Image.SCALE_SMOOTH);
                    icone = new ImageIcon(img);
                    
                    lblFormaP2.setIcon(icone);
                }

                encherCbx(cbxFormaP1, "1");
            }
        });
        
        encherCbx(cbxFormaP1, "1");
        encherCbx(cbxFormaP2, "2");

        btnCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(
                    !txfNomeP1.getText().trim().isEmpty() &&
                    !txfNomeP2.getText().trim().isEmpty() &&
                    cbxFormaP1.getSelectedItem() != null &&
                    cbxFormaP2.getSelectedItem() != null
                ){
                    Globals.getP1().setNome(txfNomeP1.getText());
                    Globals.getP2().setNome(txfNomeP2.getText());
                    
                    //Jeito de fazer 1º
                    String recursoP1 =  "/JogoDaVelha/Formas/" + opcoesP1.get( cbxFormaP1.getSelectedIndex() );
                    //System.out.println(recursoP1);
                    URL URLp1 = getClass().getResource(recursoP1);
                    ImageIcon imgP1 = new ImageIcon();
                    if(URLp1 != null){
                        imgP1 = new ImageIcon(URLp1);
                        Globals.getP1().setForma(imgP1);
                        //System.out.println("Achou o p1");
                    } else {
                        //System.out.println("Não acho o caminho do P1");
                    }
                    
                    //Jeito de fazer 2º
                    Globals.getP2().setForma(new ImageIcon(getClass().getResource("/JogoDaVelha/Formas/" + opcoesP2.get( cbxFormaP2.getSelectedIndex() ) ) ) );
                    
                    Globals.getTela().getLayer().remove(pcn);
                    Globals.getTela().getLayer().add(new PanelPartida());
                    Globals.getTela().getLayer().repaint();
                } else {
                    System.out.println("Preencha");
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblP1 = new javax.swing.JLabel();
        lblP2 = new javax.swing.JLabel();
        lblN1 = new javax.swing.JLabel();
        lblN2 = new javax.swing.JLabel();
        txfNomeP1 = new javax.swing.JTextField();
        txfNomeP2 = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        lblescolhaFormaP1 = new javax.swing.JLabel();
        lblescolhaFormaP2 = new javax.swing.JLabel();
        cbxFormaP1 = new javax.swing.JComboBox<>();
        cbxFormaP2 = new javax.swing.JComboBox<>();
        lblFormaEscolhidaP1 = new javax.swing.JLabel();
        lblFormaP1 = new javax.swing.JLabel();
        lblFormaEscolhidaP2 = new javax.swing.JLabel();
        lblFormaP2 = new javax.swing.JLabel();

        lblP1.setText("Player1");

        lblP2.setText("Player2");

        lblN1.setText("Digite seu nome");

        lblN2.setText("Digite seu nome:");

        btnCadastrar.setText("Cadastrar nomes e formas");

        lblescolhaFormaP1.setText("Escolha sua forma");

        lblescolhaFormaP2.setText("Escolha sua forma");

        cbxFormaP1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbxFormaP2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblFormaEscolhidaP1.setText("Forma escolhida:");

        lblFormaEscolhidaP2.setText("Forma escolhida:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(248, 248, 248)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblN1, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                            .addComponent(lblP1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(293, 293, 293)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblP2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblN2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(txfNomeP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(293, 293, 293)
                            .addComponent(txfNomeP2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(lblescolhaFormaP1)
                            .addGap(343, 343, 343)
                            .addComponent(lblescolhaFormaP2))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(cbxFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(293, 293, 293)
                            .addComponent(cbxFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(lblFormaEscolhidaP1)
                            .addGap(349, 349, 349)
                            .addComponent(lblFormaEscolhidaP2))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(lblFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(293, 293, 293)
                            .addComponent(lblFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(418, 418, 418)
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(367, 367, 367))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(278, 278, 278)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblP1)
                    .addComponent(lblP2))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblN1)
                    .addComponent(lblN2))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txfNomeP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfNomeP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblescolhaFormaP1)
                    .addComponent(lblescolhaFormaP2))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbxFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFormaEscolhidaP1)
                    .addComponent(lblFormaEscolhidaP2))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(195, 195, 195)
                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cbxFormaP1;
    private javax.swing.JComboBox<String> cbxFormaP2;
    private javax.swing.JLabel lblFormaEscolhidaP1;
    private javax.swing.JLabel lblFormaEscolhidaP2;
    private javax.swing.JLabel lblFormaP1;
    private javax.swing.JLabel lblFormaP2;
    private javax.swing.JLabel lblN1;
    private javax.swing.JLabel lblN2;
    private javax.swing.JLabel lblP1;
    private javax.swing.JLabel lblP2;
    private javax.swing.JLabel lblescolhaFormaP1;
    private javax.swing.JLabel lblescolhaFormaP2;
    private javax.swing.JTextField txfNomeP1;
    private javax.swing.JTextField txfNomeP2;
    // End of variables declaration//GEN-END:variables
}
