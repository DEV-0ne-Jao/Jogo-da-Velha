package JogoDaVelha;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

//Soli Deo Gloria

public class PanelCadastrar extends javax.swing.JPanel {
    public PanelCadastrar pcn = this;
    public PanelCadastrar() {
        initComponents();
        this.setBounds(Globals.getTela().getLayer().getBounds());
        Globals.getTela().getLayer().repaint();
        
        encherCbx(cbxFormaP1);
        encherCbx(cbxFormaP2);
        
        
        
        btnCadastrar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(txfNomeP1.getText().trim().isEmpty() && txfNomeP2.getText().trim().isEmpty()) {
                    Globals.getP1().setNome(txfNomeP1.getText());
                    Globals.getP2().setNome(txfNomeP2.getText());
                    Globals.getTela().getLayer().remove(pcn);
                } else {
                    
                }
            }
        });
    }
    public void encherCbx(JComboBox cbx, JLabel label) {        
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        
        String cBase = "/jogoDaVelha/Formas/";
        
        List<String> opcoes = new ArrayList<>();
        
        File pasta = new File("src/JogoDaVelha/Formas");
        File[] arquivos = pasta.listFiles();
        for (File arquivo : arquivos) {
            if (arquivo.isFile()) {
                opcoes.add( arquivo.getName() );
            }
        }
        
        for (int i = 0; i < opcoes.size(); i++) {
            modelo.addElement( opcoes.get(i).split(".")[0] );
        }
        
        cbx.setModel(modelo);
        cbx.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
            
        });
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblP1 = new javax.swing.JLabel();
        lblP2 = new javax.swing.JLabel();
        lblN1 = new javax.swing.JLabel();
        lblN2 = new javax.swing.JLabel();
        txfNomeP1 = new javax.swing.JTextField();
        txfNomeP2 = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        lblescolhaFormaP1 = new javax.swing.JLabel();
        lblescolhaFormaP2 = new javax.swing.JLabel();
        cbxFormaP1 = new javax.swing.JComboBox<>();
        cbxFormaP2 = new javax.swing.JComboBox<>();
        lblFormaEscolhidaP1 = new javax.swing.JLabel();
        lblFormaP1 = new javax.swing.JLabel();
        lblFormaEscolhidaP2 = new javax.swing.JLabel();
        lblFormaP2 = new javax.swing.JLabel();

        lblP1.setText("Player1");

        lblP2.setText("Player2");

        lblN1.setText("Digite seu nome");

        lblN2.setText("Digite seu nome:");

        btnCadastrar.setText("Cadastrar nomes e formas");

        lblescolhaFormaP1.setText("Escolha sua forma");

        lblescolhaFormaP2.setText("Escolha sua forma");

        cbxFormaP1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbxFormaP2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblFormaEscolhidaP1.setText("Forma escolhida:");

        lblFormaEscolhidaP2.setText("Forma escolhida:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(248, 248, 248)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFormaEscolhidaP1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblN1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblP1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txfNomeP1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                            .addComponent(lblescolhaFormaP1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxFormaP1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblFormaP1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(293, 293, 293)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblFormaEscolhidaP2)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txfNomeP2)
                                        .addComponent(lblP2)
                                        .addComponent(lblN2)
                                        .addComponent(lblescolhaFormaP2)
                                        .addComponent(cbxFormaP2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblFormaP2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(367, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(278, 278, 278)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblP1)
                    .addComponent(lblP2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblN1)
                    .addComponent(lblN2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txfNomeP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfNomeP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblescolhaFormaP1)
                    .addComponent(lblescolhaFormaP2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFormaEscolhidaP1)
                    .addComponent(lblFormaEscolhidaP2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFormaP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFormaP2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(195, 195, 195)
                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cbxFormaP1;
    private javax.swing.JComboBox<String> cbxFormaP2;
    private javax.swing.JLabel lblFormaEscolhidaP1;
    private javax.swing.JLabel lblFormaEscolhidaP2;
    private javax.swing.JLabel lblFormaP1;
    private javax.swing.JLabel lblFormaP2;
    private javax.swing.JLabel lblN1;
    private javax.swing.JLabel lblN2;
    private javax.swing.JLabel lblP1;
    private javax.swing.JLabel lblP2;
    private javax.swing.JLabel lblescolhaFormaP1;
    private javax.swing.JLabel lblescolhaFormaP2;
    private javax.swing.JTextField txfNomeP1;
    private javax.swing.JTextField txfNomeP2;
    // End of variables declaration//GEN-END:variables
}
